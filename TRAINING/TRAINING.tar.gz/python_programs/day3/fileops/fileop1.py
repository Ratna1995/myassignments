f1 = open("a.txt","r")

#print f1.read()
#print f1.readline()
print f1.readlines()
f1.close()
