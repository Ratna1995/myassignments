def func2():
	print ("i am in module 2")
