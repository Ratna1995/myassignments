def func3():
	print ("i am in module 3")
