import package3
from package3 import module1
from package3 import module2
from package3 import module3

module1.func1()
module2.func2()
module3.func3()
