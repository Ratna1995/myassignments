import package1

package1.func1()
package1.func2()
package1.func3()
