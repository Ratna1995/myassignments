from module1 import func1
from module2 import func2
from module3 import func3
