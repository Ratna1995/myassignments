import package2

package2.module1.func1()
package2.module2.func2()
package2.module3.func3()
