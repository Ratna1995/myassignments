x = 100

def func1():
	x = 10
	y = 20
	print "locals :",locals()

func1()
print "globals :",globals()
