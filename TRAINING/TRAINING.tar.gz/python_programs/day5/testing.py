def myAvg(a,b):
	"""
	>>> myAvg(10, 30)
	20
	>>> myAvg(40, 60)
	50
	"""
	return (a+b)/2

import doctest
doctest.testmod()
