import re

str1 = raw_input("enter a string: ")

print re.escape("[]")
