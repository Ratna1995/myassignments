#! /usr/bin/python
print "script mode"
