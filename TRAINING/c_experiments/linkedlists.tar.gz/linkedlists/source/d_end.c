#include"header.h"                                                              
                                                                                
void d_end()                                                                  
{              
	int i = 0;                                                                 
    sl *curr;                                                                   
                                                                                
    if(NULL == (curr = (sl *)malloc(sizeof(sl)))) {                             
        perror("MAlloc fails");                                                 
        exit(EXIT_FAILURE);                                                     
    }                                                                           
                                                                                
    curr = head;                                                                
    while((curr) != NULL)                                                       
    {                                                                           
        printf("%d\t",(curr -> data));                                          
        curr = curr -> link;
		i++;                                                    
    }       
	
	del_node(i);                                                   
}                                                                                
