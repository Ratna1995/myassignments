#include"header.h"                                                              
                                                                                
void d_middle()                                                                    
{                                                                                  
	int i = 0;                                                               
    sl *curr;         
	                                                        
                                                                                
    if(NULL == (curr = (sl *)malloc(sizeof(sl)))) {             
        perror("MAlloc fails");                                                 
        exit(EXIT_FAILURE);                                                     
    }                                                                             
	
	curr = head;                                                                
    while((curr) != NULL)                                                       
    {                                                                           
        curr = curr -> link;                                                
		i++;
	}                                                               
    del_node(i/2);                                                              
}
