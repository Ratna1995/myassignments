#include"header.h"

void del_node(int pos)
{
	int i = 0;                                                                  
    sl *curr;
	sl *temp;                                                                   
                                                                                
    pos = pos - 2;                                                                            
    if(NULL == (curr = (sl *)malloc(sizeof(sl)))) {                               
        perror("MAlloc fails");                                                 
        exit(EXIT_FAILURE);                                                     
    }       

	if(NULL == (temp = (sl *)malloc(sizeof(sl)))) {                               
        perror("MAlloc fails");                                                 
        exit(EXIT_FAILURE);                                                     
    }                                                                     
                                                                                
    curr = head;                                                                
    while((curr) != NULL)                                                       
    {       
		if(i != pos)                                                                    
        	curr = curr -> link;                                                    
        i++;                                                                    
    }
	  
	temp = curr;
	curr = curr -> link;
	temp -> link = curr -> link;
}
